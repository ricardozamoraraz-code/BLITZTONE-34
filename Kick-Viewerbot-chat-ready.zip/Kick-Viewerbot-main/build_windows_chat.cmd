@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Missing .venv. Create it and install requirements.txt and requirements-chat.txt first.
  exit /b 1
)

set "NODE_EXE="
for /f "delims=" %%N in ('where.exe node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE (
  echo Node.js was not found. Install Node.js LTS and reopen this terminal.
  exit /b 1
)

echo Building the local Next.js frontend...
call npm.cmd --prefix frontend install
if errorlevel 1 exit /b 1
call npm.cmd --prefix frontend run build
if errorlevel 1 exit /b 1
if not exist "frontend\.next\standalone\server.js" (
  echo Next.js standalone output was not created.
  exit /b 1
)

if exist frontend_bundle rmdir /s /q frontend_bundle
mkdir frontend_bundle
xcopy /E /I /Y "frontend\.next\standalone\*" "frontend_bundle\" >nul
if errorlevel 2 exit /b 1
if exist "frontend\.next\static" (
  mkdir "frontend_bundle\.next\static"
  xcopy /E /I /Y "frontend\.next\static\*" "frontend_bundle\.next\static\" >nul
  if errorlevel 2 exit /b 1
)
if exist "frontend\public" (
  mkdir "frontend_bundle\public"
  xcopy /E /I /Y "frontend\public\*" "frontend_bundle\public\" >nul
  if errorlevel 2 exit /b 1
)
copy /Y "%NODE_EXE%" "frontend_bundle\node.exe" >nul
if errorlevel 1 exit /b 1

echo Installing PyInstaller...
".venv\Scripts\python.exe" -m pip install pyinstaller
if errorlevel 1 exit /b 1

echo Packaging backend, local frontend, Node.js, and AI libraries. This may take a while and produce a large EXE.
set "KICK_BOT_WITH_CHAT=1"
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean KickViewerBOT.spec
if errorlevel 1 exit /b 1

echo.
echo Finished: dist\KickViewerBOT.exe
echo The EXE opens its bundled local interface and starts the AI model on first launch.
endlocal
