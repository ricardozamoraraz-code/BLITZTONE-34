/**
 * WebSocket Service - Communication complète via WebSocket
 */
import { io, Socket } from "socket.io-client";
import { generateConnectionUrls } from "../config/ports";

export type ConnectionStatus =
  | "disconnected"
  | "connecting"
  | "connected"
  | "error";

export interface BotConfig {
  channelName: string;
  threads: number;
  timeout?: number;
  proxyType?: string;
  stabilityMode?: boolean;
  proxyFile?: File;
  subscriptionStatus?: boolean;
}

export interface BotStats {
  is_running: boolean;
  channel_name?: string;
  active_threads: number;
  total_proxies: number;
  alive_proxies: number;
  request_count: number;
  config: any;
  status: any;
  system_metrics: {
    cpu: number;
    memory: number;
    network_up: number;
    network_down: number;
  };
}

interface Callbacks {
  onConnect?: () => void;
  onDisconnect?: () => void;
  onStatsUpdate?: (stats: BotStats) => void;
  onBotStarted?: (data: any) => void;
  onBotStopped?: (data: any) => void;
  onBotError?: (error: string) => void;
  onChatStatus?: (status: { available: boolean; status?: string; message?: string }) => void;
  onKickChatStatus?: (status: { enabled: boolean; status?: string; channel?: string }) => void;
  onKickChatError?: (error: string) => void;
  onKickChatStarted?: (data: { channel?: string; message?: string }) => void;
  onKickChatStopped?: () => void;
  onStatusChange?: (status: ConnectionStatus) => void;
}

class WebSocketService {
  private socket: Socket | null = null;
  private status: ConnectionStatus = "disconnected";
  private callbacks: Callbacks = {};

  // URLs possibles pour le service local (générées depuis la config partagée)
  private urls = generateConnectionUrls();

  private currentUrl = "";

  constructor(callbacks: Callbacks = {}) {
    this.callbacks = callbacks;
  }

  /**
   * Se connecter au service WebSocket
   */
  async connect(): Promise<boolean> {
    this.updateStatus("connecting");

    for (const url of this.urls) {
      console.log(`Tentative de connexion à ${url}...`);

      const success = await this.tryConnect(url);
      if (success) {
        this.currentUrl = url;
        console.log(`✅ Connecté à ${url}`);
        return true;
      }
    }

    this.updateStatus("error");
    this.callbacks.onBotError?.("Impossible de se connecter au service local");
    return false;
  }

  /**
   * Essayer de se connecter à une URL spécifique
   */
  private tryConnect(url: string): Promise<boolean> {
    return new Promise((resolve) => {
      const socket = io(url, {
        transports: ["websocket", "polling"],
        reconnection: false,
        timeout: 3000,
      });

      const timeout = setTimeout(() => {
        socket.close();
        resolve(false);
      }, 3000);

      socket.on("connect", () => {
        clearTimeout(timeout);
        this.socket = socket;
        this.setupEventHandlers();
        this.updateStatus("connected");
        this.callbacks.onConnect?.();
        resolve(true);
      });

      socket.on("connect_error", () => {
        clearTimeout(timeout);
        socket.close();
        resolve(false);
      });
    });
  }

  /**
   * Configurer les gestionnaires d'événements
   */
  private setupEventHandlers() {
    if (!this.socket) return;

    this.socket.on("connected", (data) => {
      console.log("Serveur connecté:", data);
    });

    this.socket.on("stats_update", (stats: BotStats) => {
      this.callbacks.onStatsUpdate?.(stats);
    });

    this.socket.on("bot_started", (data) => {
      console.log("Bot démarré:", data);
      this.callbacks.onBotStarted?.(data);
    });

    this.socket.on("bot_stopped", (data) => {
      console.log("Bot arrêté:", data);
      this.callbacks.onBotStopped?.(data);
    });

    this.socket.on("bot_status_changed", (data) => {
      console.log("Statut bot changé:", data);
    });

    this.socket.on("bot_error", (error) => {
      console.error("Erreur bot:", error);
      this.callbacks.onBotError?.(error.error || "Erreur inconnue");
    });

    this.socket.on("disconnect", () => {
      this.updateStatus("disconnected");
      this.callbacks.onDisconnect?.();
    });

    this.socket.on("pong", (data) => {
      console.log("Pong reçu:", data);
    });

    this.socket.on("chat_status_response", (data) => {
      this.callbacks.onChatStatus?.(data);
    });
    this.socket.on("kick_chat_status_response", (data) => {
      this.callbacks.onKickChatStatus?.(data);
    });
    this.socket.on("kick_chat_error", (data) => {
      this.callbacks.onKickChatError?.(data.error || "Could not start chat bot");
    });
    this.socket.on("kick_chat_started", (data) => {
      this.callbacks.onKickChatStarted?.(data);
    });
    this.socket.on("kick_chat_stopped", () => {
      this.callbacks.onKickChatStopped?.();
    });
  }

  /**
   * Démarrer le bot
   */
  async startBot(config: BotConfig): Promise<void> {
    if (!this.socket || this.status !== "connected") {
      throw new Error("Service non connecté");
    }

    const data: Record<string, unknown> = {
      channelName: config.channelName,
      threads: config.threads,
      timeout: config.timeout || 10000,
      proxyType: config.proxyType || "http",
      stabilityMode: config.stabilityMode || false,
      subscriptionStatus: config.subscriptionStatus || "unknown",
    };

    // Si un fichier proxy est fourni, le convertir en base64
    if (config.proxyFile) {
      const base64 = await this.fileToBase64(config.proxyFile);
      data.proxyFileData = base64;
      data.proxyFileName = config.proxyFile.name;
    }

    this.socket.emit("start_bot", data);
  }

  /**
   * Arrêter le bot
   */
  stopBot(): void {
    if (!this.socket || this.status !== "connected") {
      throw new Error("Service non connecté");
    }

    this.socket.emit("stop_bot");
  }

  /**
   * Demander les statistiques
   */
  getStats(): void {
    if (!this.socket || this.status !== "connected") {
      return;
    }

    this.socket.emit("get_stats");
  }

  getChatStatus(): void {
    if (this.socket && this.status === "connected") this.socket.emit("chat_status");
  }

  getKickChatStatus(): void {
    if (this.socket && this.status === "connected") this.socket.emit("kick_chat_status");
  }

  startKickChat(options: { channelName: string; authToken: string; responseChance: number; minInterval: number }): void {
    if (!this.socket || this.status !== "connected") throw new Error("Local backend is not connected");
    this.socket.emit("kick_chat_start", {
      channel_name: options.channelName,
      auth_token: options.authToken,
      response_chance: options.responseChance,
      min_interval: options.minInterval,
    });
  }

  stopKickChat(): void {
    if (!this.socket || this.status !== "connected") throw new Error("Local backend is not connected");
    this.socket.emit("kick_chat_stop");
  }

  /**
   * Ping le serveur
   */
  ping(): void {
    if (!this.socket || this.status !== "connected") {
      return;
    }

    this.socket.emit("ping");
  }

  /**
   * Se déconnecter
   */
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
    this.updateStatus("disconnected");
  }

  /**
   * Obtenir le statut de connexion
   */
  getStatus(): ConnectionStatus {
    return this.status;
  }

  /**
   * Obtenir l'URL actuelle
   */
  getCurrentUrl(): string {
    return this.currentUrl;
  }

  /**
   * Vérifier si connecté
   */
  isConnected(): boolean {
    return this.status === "connected";
  }

  /**
   * Mettre à jour le statut
   */
  private updateStatus(status: ConnectionStatus) {
    this.status = status;
    this.callbacks.onStatusChange?.(status);
  }

  /**
   * Convertir un fichier en base64
   */
  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}

export default WebSocketService;
