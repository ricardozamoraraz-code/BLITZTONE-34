"use client";
import { useEffect, useState, useCallback, useRef } from "react";
import WebSocketService, {
  BotStats,
  BotConfig,
  ConnectionStatus,
} from "@/services/WebSocketService";

export interface ChatServiceStatus {
  available: boolean;
  status?: "ready" | "loading" | "not_loaded";
  message?: string;
}

export interface KickChatStatus {
  enabled: boolean;
  status?: string;
  channel?: string;
}

export function useWebSocketBot() {
  const [isConnected, setIsConnected] = useState(false);
  const [status, setStatus] = useState<ConnectionStatus>("disconnected");
  const [stats, setStats] = useState<BotStats | null>(null);
  const [error, setError] = useState<string>("");
  const [chatStatus, setChatStatus] = useState<ChatServiceStatus>({
    available: false,
    status: "not_loaded",
    message: "Checking AI chat service…",
  });
  const [kickChatStatus, setKickChatStatus] = useState<KickChatStatus>({ enabled: false });
  const [kickChatError, setKickChatError] = useState("");
  const wsRef = useRef<WebSocketService | null>(null);

  useEffect(() => {
    // Créer le service WebSocket
    const ws = new WebSocketService({
      onConnect: () => {
        setIsConnected(true);
        setError("");
        // Demander les stats immédiatement après connexion
        ws.getStats();
        ws.getChatStatus();
        ws.getKickChatStatus();
      },
      onDisconnect: () => {
        setIsConnected(false);
      },
      onStatsUpdate: (newStats) => {
        setStats(newStats);
      },
      onBotStarted: (data) => {
        ws.getStats();
      },
      onBotStopped: (data) => {
        ws.getStats();
      },
      onBotError: (errorMsg) => {
        setError(errorMsg);
      },
      onChatStatus: (newStatus) => setChatStatus(newStatus),
      onKickChatStatus: (newStatus) => setKickChatStatus(newStatus),
      onKickChatError: (errorMsg) => setKickChatError(errorMsg),
      onKickChatStarted: (data) => {
        setKickChatError("");
        setKickChatStatus({ enabled: true, status: "running", channel: data.channel });
      },
      onKickChatStopped: () => setKickChatStatus({ enabled: false, status: "not_running" }),
      onStatusChange: (newStatus) => {
        setStatus(newStatus);
      },
    });

    wsRef.current = ws;

    // Se connecter automatiquement
    ws.connect();

    // Demander les stats régulièrement
    const statsInterval = setInterval(() => {
      if (ws.isConnected()) {
        ws.getStats();
        ws.getChatStatus();
        ws.getKickChatStatus();
      }
    }, 10000);

    // Cleanup
    return () => {
      clearInterval(statsInterval);
      ws.disconnect();
    };
  }, []);

  const startBot = useCallback(async (config: BotConfig) => {
    if (!wsRef.current) {
      throw new Error("WebSocket service not initialized");
    }

    try {
      await wsRef.current.startBot(config);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to start bot");
      throw err;
    }
  }, []);

  const stopBot = useCallback(() => {
    if (!wsRef.current) {
      throw new Error("WebSocket service not initialized");
    }

    try {
      wsRef.current.stopBot();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to stop bot");
      throw err;
    }
  }, []);

  const reconnect = useCallback(async () => {
    if (wsRef.current) {
      await wsRef.current.connect();
    }
  }, []);

  const getCurrentUrl = useCallback(() => {
    return wsRef.current?.getCurrentUrl() || "";
  }, []);

  const startKickChat = useCallback((options: { channelName: string; authToken: string; responseChance: number; minInterval: number }) => {
    if (!wsRef.current) throw new Error("WebSocket service not initialized");
    setKickChatError("");
    wsRef.current.startKickChat(options);
  }, []);

  const stopKickChat = useCallback(() => {
    if (!wsRef.current) throw new Error("WebSocket service not initialized");
    wsRef.current.stopKickChat();
  }, []);

  return {
    // Connection state
    isConnected,
    status,
    error,
    currentUrl: getCurrentUrl(),

    // Bot stats
    stats,
    isRunning: stats?.is_running || false,

    // Actions
    startBot,
    stopBot,
    reconnect,
    chatStatus,
    kickChatStatus,
    kickChatError,
    startKickChat,
    stopKickChat,
  };
}
