# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

import os
import sys
from pathlib import Path

# Note: tls_client binaries are now handled by hooks/hook-tls_client.py
tls_client_binaries = []


# Use the current Python environment's site-packages (works for venv and CI)
import site
site_packages = site.getsitepackages()[0]

# Build data list - only include actual data files, not Python packages
datas = [
    ('backend', '.'),
]

# Include the local UI and AI stack only when explicitly requested. The
# Windows build script prepares frontend_bundle and PyTorch makes the EXE large.
chat_datas = []
chat_binaries = []
chat_hiddenimports = ['services.chat_service', 'services.kick_chat_bot']
include_chat = os.getenv('KICK_BOT_WITH_CHAT', '').lower() in ('1', 'true', 'yes')
if include_chat:
    from PyInstaller.utils.hooks import collect_all
    for package in ('torch', 'transformers'):
        package_datas, package_binaries, package_hiddenimports = collect_all(package)
        chat_datas += package_datas
        chat_binaries += package_binaries
        chat_hiddenimports += package_hiddenimports

    frontend_bundle = Path('frontend_bundle').resolve()
    if not (frontend_bundle / 'server.js').is_file():
        raise SystemExit('Missing frontend_bundle/server.js. Run build_windows_chat.cmd first.')
    if not (frontend_bundle / 'node.exe').is_file():
        raise SystemExit('Missing frontend_bundle/node.exe. Run build_windows_chat.cmd first.')
    for frontend_file in frontend_bundle.rglob('*'):
        if not frontend_file.is_file():
            continue
        relative_parent = frontend_file.parent.relative_to(frontend_bundle)
        destination = Path('frontend_bundle') / relative_parent
        if frontend_file.name.lower() == 'node.exe':
            chat_binaries.append((str(frontend_file), str(destination)))
        else:
            chat_datas.append((str(frontend_file), str(destination)))
 # Force include tls_client package
try:
    import importlib.util
    package_name = 'tls_client'
    spec = importlib.util.find_spec(package_name)
    if spec and spec.origin:
        tls_client_path = os.path.dirname(spec.origin)
        datas.append((tls_client_path, package_name))
        print(f"[OK] Added {package_name} package from: {tls_client_path}")
    else:
        print(f"[WARNING] {package_name} not found in build environment (find_spec failed)!")
except Exception as e:
    print(f"[WARNING] Failed to find {package_name}: {e}")

# Add fake_useragent data files manually (hooks don't always catch data files)
try:
    import fake_useragent
    fake_useragent_base = os.path.dirname(fake_useragent.__file__)
    fake_useragent_data = os.path.join(fake_useragent_base, 'data')

    if os.path.exists(fake_useragent_data):
        # Add the entire data directory with its contents
        datas.append((fake_useragent_data, 'fake_useragent/data'))
        print(f"[OK] Added fake_useragent data: {fake_useragent_data}")

    # Also add py.typed if it exists
    py_typed = os.path.join(fake_useragent_base, 'py.typed')
    if os.path.exists(py_typed):
        datas.append((py_typed, 'fake_useragent'))

except Exception as e:
    print(f"[WARNING] Could not add fake_useragent data: {e}")

a = Analysis(
    ['backend/main.py'],
    pathex=[],
    binaries=tls_client_binaries + chat_binaries,
    datas=datas + chat_datas,
    hiddenimports=[
        # Flask and related
        'flask',
        'flask_cors',
        'flask_socketio',
        'socketio',
        'werkzeug',
        'gevent',
        'gevent.socket',
        'gevent.select',
        'gevent._socket3',
        'gevent.resolver.thread',
        'gevent.resolver.ares',
        'gevent.resolver.blocking',
        'gevent.event',
        'gevent.queue',
        'dns',
        'dns.dnssec',
        'dns.e164',
        'dns.hash',
        'dns.namedict',
        'dns.tsigkeyring',
        'dns.update',
        'dns.version',
        'dns.zone',
        # Network and HTTP
        'requests',
        'urllib3',
        'certifi',
        'charset_normalizer',
        'idna',
        # Websockets
        'websockets',
        'websockets.legacy',
        'websockets.legacy.client',
        'websockets.legacy.server',
        # Streaming
        'streamlink',
        'streamlink.plugins',
        # fake_useragent and its submodules
        'fake_useragent',
        'fake_useragent.data',
        'fake_useragent.utils',
        'fake_useragent.fake',
        'fake_useragent.errors',
        # TLS Client
        'tls_client',
        'tls_client.dependencies',
        # UI
        'rich',
        'rich.console',
        'rich.progress',
        'rich.table',
        # Monitoring
        'psutil',
        'services.chat_service',
        'services.kick_chat_bot',
        # Other
        'cffi',
        'engineio',
        'engineio.async_drivers',
        'engineio.async_drivers.gevent',
        'python_socks',
        'python_socks.async_',
        'python_socks.sync',
        'python_socks.async_.asyncio',
        'python_socks.async_.trio',
        'python_socks.async_.curio',
        'python_socks.async_.anyio',
    ] + chat_hiddenimports,
    hookspath=['hooks'],
    hooksconfig={},
    runtime_hooks=['hooks/runtime-hook-fake_useragent.py'],
    excludes=[],
    cipher=block_cipher,
    noarchive=False,
)

# Collect all submodules and data
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='KickViewerBOT',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    uac_admin=False,
    icon='frontend/public/favicon.ico'
)
